<?php
class Home{
    public function index(){
        echo "index";
    }
    
}