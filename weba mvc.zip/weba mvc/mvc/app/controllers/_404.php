<?php

class _404{
    public function index(){
        echo 'Controller not found';
    }
}